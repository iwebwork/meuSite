<h1>Você tem <?php echo $quantidade;?> anuncios</h1>
<hr>
<h1>E <?php echo $usuarios?> usuarios</h1>
<img src="http://www.google.com.br/google.jpg">