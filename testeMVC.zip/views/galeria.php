

<h1><?php echo $nome?> Ele tem <?php echo $quantidade?> de fotos<h1/>