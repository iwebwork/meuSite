function alert(){
    document.getElementById("resultado").innerHTML = "Bem vindo ao site em mvc";
}