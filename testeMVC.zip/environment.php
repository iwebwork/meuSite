<?php
    //Usado para a conexão local do banco
    define("ENVIRONMENT","development");

    //Usada para a conexão remota do banco
    //define("ENVIRONMENT","production");